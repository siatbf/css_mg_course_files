add this to databases.cfg

	"shavit"
	{
		"driver"	"sqlite"
		"database"	"shavit"
	}